﻿using GREPO;

namespace DALJSONXG;

public interface IRepository : IRepository<WSRef, Comment>;

public class Repository : IRepository
{
    private readonly JSONContext context;
    private readonly string fileName = "data_generic.json";

    public Repository()
    {
        context = JSONContext.Create(fileName);
    }

    public List<Comment> getAllComment()
    {
        return context.Comments ?? new List<Comment>();
    }

    public List<WSRef> getAllWSRef()
    {
        return context.WSRefs ?? new List<WSRef>();
    }

    public bool addWSRef(WSRef wsref)
    {
        if (wsref == null || context.WSRefs == null)
            return false;

        wsref.Id = context.WSRefs.Any() ? context.WSRefs.Max(w => w.Id) + 1 : 1;
        context.WSRefs.Add(wsref);
        return context.SaveChanges() > 0;
    }

    public bool addComment(Comment comment)
    {
        if (comment == null || context.WSRefs == null || context.Comments == null)
            return false;

        // Генерируем ID для комментария
        comment.Id = context.Comments.Any() ? context.Comments.Max(c => c.Id) + 1 : 1;

        // Добавляем комментарий в общий список
        context.Comments.Add(comment);

        // Связываем комментарий с WSRef
        var wsref = context.WSRefs.FirstOrDefault(w => w.Id == comment.WSrefId);
        if (wsref != null)
        {
            wsref.Comments ??= new List<Comment>();
            wsref.Comments.Add(comment);
        }

        return context.SaveChanges() > 0;
    }

    public Comment? GetCommentById(int id)
    {
        return context.Comments?.FirstOrDefault(c => c.Id == id);
    }

    public void Dispose() { }
}