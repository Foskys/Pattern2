﻿using DALMSQLXG;
using DALJSONXG;
using GREPO;

class Program
{
    static void Main()
    {
        Console.WriteLine("Testing Json ");
        TestJsonG();

        Console.WriteLine("Testing SQL ");
        TestMSQLG();
    }

    public static void TestJsonG()
    {
        DALJSONXG.Init.Execute();

        using (DALJSONXG.IRepository repo = new DALJSONXG.Repository())
        {
            Console.WriteLine("\nПолучение всех WSRefs:");
            repo.getAllWSRef().ForEach(wsRef =>
            {
                Console.WriteLine($"WSRefs: {wsRef.Id}: {wsRef.Url}, {wsRef.Description}, {wsRef.Minus}, {wsRef.Plus}");
            });

            Console.WriteLine("\nПолучение всех Comments:");
            repo.getAllComment().ForEach(comment =>
            {
                Console.WriteLine($"Comments {comment.Id}: {comment.Commtext}, {comment.Stamp}, {comment.WSrefId}");
            });

            Console.WriteLine("Добавление WSRef:");
            if (repo.addWSRef(new WSRef() { Url = "https://www.belstu.by", Description = "БГТУ", Minus = 0, Plus = 0})) Console.WriteLine("WSRefs: Add");
            else Console.WriteLine("WSRefs: Error Add");

            Console.WriteLine("Добавление Comment 1:");
            if (repo.addComment(new Comment() { WSrefId = 4, Commtext = "Первый комментарий", Stamp = DateTime.Now }))
                Console.WriteLine("Comments: Add");
            else
                Console.WriteLine("Comments: Error Add");

            Console.WriteLine("Добавление Comment 2:");
            if (repo.addComment(new Comment() { WSrefId = 4, Commtext = "Второй комментарий", Stamp = DateTime.Now }))
                Console.WriteLine("Comments: Add");
            else
                Console.WriteLine("Comments: Error Add");


            Console.WriteLine("После добавления addWSRef, addComment");


            Console.WriteLine("\nПолучение всех WSRefs:");
            repo.getAllWSRef().ForEach(wsRef =>
            {
                Console.WriteLine($"WSRefs: {wsRef.Id}: {wsRef.Url}, {wsRef.Description}, {wsRef.Minus}, {wsRef.Plus}");
            });

            Console.WriteLine("\nПолучение всех Comments:");
            repo.getAllComment().ForEach(comment =>
            {
                Console.WriteLine($"Comments {comment.Id}: {comment.Commtext}, {comment.Stamp}, {comment.WSrefId}");
            });
        }
        Console.WriteLine("Finish\n\n");
    }

    public static void TestMSQLG()
    {
        DALMSQLXG.Init.Execute();

        using (DALMSQLXG.IRepository repo = new DALMSQLXG.Repository())
        {
            Console.WriteLine("\nПолучение всех WSRefs:");
            repo.getAllWSRef().ForEach(wsRef =>
            {
                Console.WriteLine($"WSRefs: {wsRef.Id}: {wsRef.Url}, {wsRef.Description}, {wsRef.Minus}, {wsRef.Plus}");
            });

            Console.WriteLine("\nПолучение всех Comments:");
            repo.getAllComment().ForEach(comment =>
            {
                Console.WriteLine($"Comments {comment.Id}: {comment.Commtext}, {comment.Stamp}, {comment.WSrefId}");
            });

            Console.WriteLine("Добавление WSRef:");
            if (repo.addWSRef(new WSRef() { Url = "https://www.belstu.by", Description = "БГТУ", Minus = 0, Plus = 0 })) Console.WriteLine("WSRefs: Add");
            else Console.WriteLine("WSRefs: Error Add");

            Console.WriteLine("Добавление Comment:");
            if (repo.addComment(new Comment() { WSrefId = 3, Commtext = "test", Stamp = DateTime.Now })) Console.WriteLine("Comments: Add");
            else Console.WriteLine("Comments: Error Add");

            Console.WriteLine("После добавления addWSRef, addComment");


            Console.WriteLine("\nПолучение всех WSRefs:");
            repo.getAllWSRef().ForEach(wsRef =>
            {
                Console.WriteLine($"WSRefs: {wsRef.Id}: {wsRef.Url}, {wsRef.Description}, {wsRef.Minus}, {wsRef.Plus}");
            });

            Console.WriteLine("\nПолучение всех Comments:");
            repo.getAllComment().ForEach(comment =>
            {
                Console.WriteLine($"Comments {comment.Id}: {comment.Commtext}, {comment.Stamp}, {comment.WSrefId}");
            });
        }
        Console.WriteLine("Finish\n\n");
    }
}