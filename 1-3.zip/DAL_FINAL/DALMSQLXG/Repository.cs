﻿using GREPO;

namespace DALMSQLXG;

public interface IRepository : IRepository<WSRef, Comment>;

public class Repository : IRepository
{
    private readonly Context context;

    public Repository()
    {
        context = new Context();
    }

    public List<Comment> getAllComment()
    {
        return context.Comments.ToList();
    }

    public List<WSRef> getAllWSRef()
    {
        return context.WSRefs.ToList();
    }

    public bool addWSRef(WSRef wsRef)
    {
        try
        {
            context.Add(wsRef);
            context.SaveChanges();
            return true;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка при добавлении WSRef: {ex.Message}");
            return false;
        }
    }

    public bool addComment(Comment comment)
    {
        try
        {
            context.Add(comment);
            context.SaveChanges();
            return true;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка при добавлении комментария: {ex.Message}");
            return false;
        }
    }

    public Comment? GetCommentById(int id)
    {
        return context.Comments.FirstOrDefault(c => c.Id == id);
    }

    public void Dispose()
    {
        context.Dispose();
    }
}