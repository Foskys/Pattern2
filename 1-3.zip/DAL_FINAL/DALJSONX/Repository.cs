﻿namespace DALJSONX;
using REPO;
public class Repository : IRepository
{
    JSONContext context;
    private Repository()
    {
        context = JSONContext.Create("WSRefNEW.json");
    }

    public static IRepository Create()
    {
        return new Repository();
    }

    public List<Comment> getAllComment()
    {
        return context.Comments == null ? new List<Comment>() : context.Comments;
    }

    public List<WSRef> getAllWSRef()
    {
        return context.WSRefs == null ? new List<WSRef>() : context.WSRefs;
    }

    public Comment? getCommentById(int id)
    {
        return context.Comments.FirstOrDefault(c => c.Id == id);
    }

    public bool addWSRef(WSRef wsref)
    {
        bool rc = false;

        if (wsref != null && context.WSRefs != null)
        {
            wsref.Id = context.WSRefs.Any() ? context.WSRefs.Max(w => w.Id) + 1 : 1;
            context.WSRefs.Add(wsref);
            rc = (context.SaveChanges() > 0);
        }

        return rc;
    }

    public bool addComment(Comment comment)
    {
        bool rc = false;

        if(!(rc = (comment == null) || (context.WSRefs == null) || (context.WSRefs.Count == 0)))
        {
            var wsref = context.WSRefs?.Where(w => w.Id == comment?.WSrefId).FirstOrDefault();

            if(wsref != null)
            {
                if(wsref.Comments == null)
                    wsref.Comments = new List<Comment>();

                wsref.Comments.Add(comment);
                rc = true;
            }
        }
        return rc;
    }

    public void Dispose()
    {
    }
}