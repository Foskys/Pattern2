﻿using Microsoft.EntityFrameworkCore;

using REPO;
namespace DALMSQLX;

public class Context : DbContext
{
    public Context() : base()
    {
        Database.EnsureCreated();
    }
    public DbSet<WSRef> WSRefs { get; set; }
    public DbSet<Comment> Comments { get; set; }
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlServer(@"Server = localhost, 1433; Database = PP; User Id = sa; Password = yourStrong(!)Password; TrustServerCertificate = True; ");
    }    
}


