﻿using REPO;
namespace DALMSQLX;

public class Init
{
    public static void Execute()
    {
        Context context  = new();

        if (context.WSRefs != null && context.Comments != null)
        {
            context.Database.EnsureCreated();

            if (!context.WSRefs.Any())
            {
                List<WSRef> refs =
                [
                    new() { Description = "Oracle", Url = @"https://www.oracle.com", Minus = 0, Plus = 0 },
                    new() { Description = "Java", Url = @"https://jakarta.ee/", Minus = 0, Plus = 0 },
                ];

                context.WSRefs.AddRange(refs);
                context.SaveChanges();

                List<Comment> comments = 
                [
                    new() {WSrefId = refs[0].Id, Stamp = DateTime.Now, Commtext = "very useful link"},
                    new() {WSrefId = refs[1].Id, Stamp = DateTime.Now, Commtext = "deprecated information"}
                ];

                context.Comments.AddRange(comments);
                context.SaveChanges();
            }
        }
    }
}