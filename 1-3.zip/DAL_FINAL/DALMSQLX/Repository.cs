﻿using REPO;
namespace DALMSQLX;

public class Repository : IRepository
{
    Context context;
    public Repository()
    {
        context = new Context();
    }

    public List<Comment> getAllComment()
    {
        try
        {
            var comments = context.Comments.ToList();
            return comments;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Exception: {ex}");
            return new List<Comment>();
        }
    }

    public List<WSRef> getAllWSRef()
    {
        try
        {
            var wsrefs = context.WSRefs.ToList();
            return wsrefs;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Exception: {ex}");
            return new List<WSRef>();
        }
    }

    public bool addWSRef(WSRef wsRef)
    {
        try
        {
            context.Add(wsRef);
            context.SaveChanges();
            return true;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Exception: {ex}");
            return false;
        }
    }

    public Comment? getCommentById(int id)
    {
        return context.Comments.FirstOrDefault(c => c.Id == id);
    }

    public void Dispose()
    {
        context.Dispose();
    }

    public bool addComment(Comment comment)
    {
        try
        {
            context.Add(comment);
            context.SaveChanges();
            return true;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Exception: {ex}");
            return false;
        }
    }
}