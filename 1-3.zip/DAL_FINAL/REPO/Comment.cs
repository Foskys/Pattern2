﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
namespace REPO;

public class Comment
{
    [Key]
    public int Id { get; set; }
    public DateTime? Stamp { get; set; }
    public string? Commtext { get; set; }

    [ForeignKey("WSRef")] //  для FK ->  WSRef(PK) 
    public int WSrefId { get; set; }   //  для FK 
}