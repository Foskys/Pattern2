﻿namespace REPO;
public interface IRepository : IDisposable
{
    List<WSRef> getAllWSRef();
    List<Comment> getAllComment();
    Comment? getCommentById(int id);
    bool addWSRef(WSRef wsRef);
    bool addComment(Comment comment);
}